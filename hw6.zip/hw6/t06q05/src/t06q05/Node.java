/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t06q05;

/**
 *
 * @author Emertat
 */
public class Node {
      int key;
    Node left;
    Node right;
    
    public Node(int key)
    {
        this.key = key;
        this.left = null;
        this.right = null;
    }
    
}
